const Discord = require('discord.js')
const client = new Discord.Client();

export default client;