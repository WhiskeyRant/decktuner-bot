// import { createUser } from '../../db/controllers';

// test('tries to create an existing user (assuming user already exists)', async () => {
//     const [user, created] = await createUser({
//         id: '831976889560203333',
//     });

//     expect(created).toBe(false);
//     expect(user.dataValues.user_id).toBe('831976889560203333');
// });