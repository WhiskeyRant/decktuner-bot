export default [
    {
        key: 'decklist',
        max_length: 100,
    },
    {
        key: 'commander',
        max_length: 150,
    },
    {
        key: 'desired_experience',
        max_length: 20,
    },
    {
        key: 'budget',
        max_length: 10,
    },
    {
        key: 'deck_goals',
        max_length: 400,
    },
    {
        key: 'tuning_goals',
        max_length: 400,
    },
];
