export default user => {
    return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=256`
}